addon.name = 'horizonguide';
addon.author = 'valzar';
addon.version = '0.2.4';
addon.desc = 'Offline Horizon wiki browser with manual guide tracking.';
require('common');
local imgui = require('imgui');
-- ImGui 1.90+ replaces the legacy border boolean with numeric child flags.
-- Ashita exports these constants through require('imgui').
local function begin_child(id, size)
    local border = ImGuiChildFlags_Borders or ImGuiChildFlags_Border;
    if border ~= nil or (tonumber(IMGUI_VERSION_NUM) or 0) >= 19000 then
        return imgui.BeginChild(id, size, border or 1, 0);
    end
    return imgui.BeginChild(id, size, true, 0);
end
local settings = require('settings');
local catalog = require('catalog');
local state = settings.load(T{ profiles = T{} });
local visible, tracker = { true }, { true };
local query, show_completed, show_planned = { '' }, { false }, { false };
local filter = 'all';
local job_choice = 'All jobs';
local job_names, job_seen = {}, {};
for _,q in ipairs(catalog) do
    for _,job in ipairs(q.jobs or {}) do
        if not job_seen[job] then job_names[#job_names + 1]=job; job_seen[job]=true; end
    end
end
table.sort(job_names);
local function matches_job(q)
    if #(q.jobs or {}) == 0 then return false; end
    if job_choice == 'All jobs' then return true; end
    for _,job in ipairs(q.jobs) do if job == job_choice then return true; end end
    return false;
end
local selected = nil;
local filtered, cache_key = {}, nil;
local searchable = {};
for i,q in ipairs(catalog) do
    local terms = q.title .. ' ' .. q.requirements .. ' ' .. q.group .. ' ' .. table.concat(q.jobs or {}, ' ');
    for _,s in ipairs(q.steps) do terms = terms .. ' ' .. s.zone .. ' ' .. s.npc; end
    searchable[i] = terms:lower();
end
local function save()
    cache_key = nil;
    settings.save();
end
settings.register('settings', 'horizonguide_settings', function(s)
    if s ~= nil then state = s; end
    cache_key = nil;
end);
local function profile()
    local ok,id,n = pcall(function()
        local party = AshitaCore:GetMemoryManager():GetParty();
        return party:GetMemberServerId(0), party:GetMemberName(0);
    end);
    if not ok or not id or id == 0 or not n or n == '' then return nil, 'No character detected'; end
    local key = tostring(id) .. ':' .. n;
    state.profiles = state.profiles or {};
    if not state.profiles[key] then state.profiles[key] = { progress = {}, completed = {}, tracked = '' }; end
    return state.profiles[key], n;
end
local function step_index(q,p)
    return math.max(1, math.min(#q.steps + 1, tonumber(p and p.progress[q.id]) or 1));
end
local function wrapped(s) if s and s ~= '' then imgui.TextWrapped(s); end end
local function show_step(s)
    wrapped(s.text);
    if s.zone ~= '' then wrapped('Zone: ' .. s.zone); end
    if s.grid ~= '' then wrapped('Map square: ' .. s.grid); end
end
local function controls(q,p)
    if not p then wrapped('Log in to save manual progress.'); return; end
    local n = step_index(q,p);
    if n <= #q.steps then
        if imgui.Button('Step done##' .. q.id) then p.progress[q.id] = n + 1; save(); end
    else
        wrapped('Guide steps finished. Quest completion has not been verified.');
    end
    if imgui.Button('Previous step##' .. q.id) then p.progress[q.id] = math.max(1,n - 1); save(); end
end
local function refresh(p, char)
    local key = query[1] .. ':' .. filter .. ':' .. tostring(show_completed[1]) .. ':' .. tostring(show_planned[1]) .. ':' .. char .. ':' .. job_choice;
    if key == cache_key then return; end
    cache_key = key; filtered = {};
    for i,q in ipairs(catalog) do
        local complete = p and p.completed[q.id];
        if (show_completed[1] or not complete) and (show_planned[1] or q.availability ~= 'unavailable')
            and (filter == 'all' or q.kind == filter or (filter == 'job' and matches_job(q))) and searchable[i]:find(query[1]:lower(),1,true) then
            filtered[#filtered + 1] = i;
        end
    end
    local found = false;
    for _,i in ipairs(filtered) do if i == selected then found = true; break; end end
    if not found then selected = filtered[1]; end
end
ashita.events.register('command', 'horizonguide_command', function(e)
    local c = e.command:lower():match('^%s*(.-)%s*$');
    if c == '/hguide' then e.blocked=true; visible[1]=not visible[1]; end
    if c == '/hguide tracker' then e.blocked=true; tracker[1]=not tracker[1]; end
end);
ashita.events.register('d3d_present', 'horizonguide_present', function()
    local p, character = profile();
    if visible[1] then
        imgui.SetNextWindowSize({ 880, 620 }, ImGuiCond_FirstUseEver);
        if imgui.Begin('HorizonGuide 0.2.4 - Wiki browser', visible) then
            wrapped('Character: ' .. character .. ' | Completion not synced | Manual tracking');
            wrapped('Imported wiki guides. Availability and steps need review; this list is not a recommendation list.');
            imgui.InputText('Search title, start NPC or location', query, 256);
            if imgui.Button('All') then filter='all'; end
            imgui.SameLine(); if imgui.Button('Quests') then filter='quest'; end
            imgui.SameLine(); if imgui.Button('Missions') then filter='mission'; end
            imgui.SameLine(); if imgui.Button('Job quests') then filter='job'; end
            if filter == 'job' then
                if imgui.BeginCombo('Job', job_choice, 0) then
                    if imgui.Selectable('All jobs', job_choice == 'All jobs') then job_choice='All jobs'; end
                    for _,job in ipairs(job_names) do
                        if imgui.Selectable(job, job_choice == job) then job_choice=job; end
                    end
                    imgui.EndCombo();
                end
            end
            imgui.Checkbox('Show manually completed',show_completed);
            imgui.SameLine(); imgui.Checkbox('Show wiki-flagged planned / unavailable',show_planned);
            refresh(p,character);
            imgui.Text(tostring(#filtered) .. ' guides shown / ' .. tostring(#catalog) .. ' imported');
            if begin_child('quest_list', { 280, 0 }) then
                for _,i in ipairs(filtered) do
                    local q=catalog[i];
                    local label=(p and p.completed[q.id] and '[Done] ' or '') .. q.title;
                    if imgui.Selectable(label .. '##' .. q.id, selected == i) then selected=i; end
                end
            end
            imgui.EndChild(); imgui.SameLine();
            if begin_child('details', { 0, 0 }) then
                local q=selected and catalog[selected];
                if q then
                    wrapped(q.title);
                    if imgui.Button('Open wiki in browser') then ashita.misc.open_url(q.source); end
                    imgui.SameLine();
                    if imgui.SmallButton('Copy wiki link') then imgui.SetClipboardText(q.source); end
                    imgui.Separator();
                    wrapped(q.kind .. ' | ' .. q.group .. ' | Server availability: ' .. q.availability);
                    wrapped(q.warnings); wrapped(q.summary);
                    if #(q.jobs or {}) > 0 then wrapped('Job: ' .. table.concat(q.jobs, ', ')); end
                    wrapped(q.requirements); wrapped('Rewards: ' .. q.rewards);
                    wrapped('Repeatable: ' .. q.repeatable);
                    if q.changes ~= '' then wrapped('HORIZON CHANGES'); wrapped(q.changes); end
                    if p then
                        if imgui.Button('Track guide') then p.tracked=q.id; tracker[1]=true; save(); end
                        if p.completed[q.id] then
                            if imgui.Button('Clear manual completion') then p.completed[q.id]=nil; save(); end
                        else
                            if imgui.Button('Mark quest complete (manual)') then
                                p.completed[q.id]=true;
                                if p.tracked==q.id then p.tracked=''; end
                                save();
                            end
                        end
                    end
                    imgui.Separator();
                    local n=step_index(q,p);
                    for j,s in ipairs(q.steps) do
                        imgui.Text((j<n and '[done] ' or j==n and '[current] ' or '') .. 'Guide block ' .. j);
                        show_step(s);
                        if p and imgui.SmallButton('Start here##' .. q.id .. '_' .. j) then p.progress[q.id]=j; save(); end
                        imgui.Separator();
                    end
                    controls(q,p);
                    wrapped('Source: ' .. q.source); wrapped('Wiki revision: ' .. q.revision);
                else wrapped('No matching guides. Try clearing the search or changing filters.'); end
            end
            imgui.EndChild();
        end
        imgui.End();
    end
    if tracker[1] and p and p.tracked ~= '' then
        local q, tracked_index;
        for i,candidate in ipairs(catalog) do
            if candidate.id==p.tracked then q=candidate; tracked_index=i; break; end
        end
        if q then
            imgui.SetNextWindowSize({ 360, 190 }, ImGuiCond_FirstUseEver);
            imgui.SetNextWindowBgAlpha(0.65);
            -- Keep a normal title bar so dragging works with every ImGui move setting.
            if imgui.Begin('Active quest - drag to move###HorizonGuideTracker',tracker) then
                local n=step_index(q,p);
                if n<=#q.steps and q.steps[n].zone ~= '' then wrapped(q.steps[n].zone); end
                imgui.PushStyleColor(ImGuiCol_Text, { 1.0, 0.82, 0.25, 1.0 });
                local open = imgui.Selectable('? ' .. q.title .. '##open_tracked', false);
                imgui.PopStyleColor();
                if open then
                    visible[1]=true; query[1]=''; filter='all'; selected=tracked_index;
                    if q.availability=='unavailable' then show_planned[1]=true; end
                    if p.completed[q.id] then show_completed[1]=true; end
                    cache_key=nil;
                end
                if n<=#q.steps then
                    imgui.Text('Step ' .. n .. ' / ' .. #q.steps .. ' (manual)');
                    local objective=q.steps[n].text:match('([^\n]+)') or q.steps[n].text;
                    if #objective>220 then objective=objective:sub(1,220) .. '...'; end
                    wrapped(objective);
                    if q.steps[n].grid~='' then wrapped('Map: ' .. q.steps[n].grid); end
                    if imgui.SmallButton('Step done##tracker') then p.progress[q.id]=n+1; save(); end
                    imgui.SameLine();
                else
                    wrapped('Guide steps finished. Confirm quest completion in the full guide.');
                end
                if imgui.SmallButton('Back##tracker') then p.progress[q.id]=math.max(1,n-1); save(); end
                imgui.SameLine();
                if imgui.SmallButton('Untrack') then p.tracked=''; save(); end
            end
            imgui.End();
        end
    end
end);
ashita.events.register('unload', 'horizonguide_unload', save);
